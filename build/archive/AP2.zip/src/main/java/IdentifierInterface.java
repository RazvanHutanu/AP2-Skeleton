public interface IdentifierInterface {
    /**************************************
     *
     * @param toAdd
     */
    public void add (char toAdd);
    public StringBuffer getIdentifier();
    public int getSize();
    public void print();
}
